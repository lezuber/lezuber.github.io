---
categories:
tags:
- 🌳 Evergreen Note
- PKM
date: 2022-10-07
title: Atomicity of Evergreen Notes
lastMod: 2022-10-07
---
Atomicity describes the objective to be as narrow as possible, while still capturing the entirety of the thing. The **atomicity** of an evergreen note is the key requirement to **allow effective linking** between them.


## Questions

  + Why is atomicity crucial for the effectiveness evergreen notes? #card

    + Atomicity describes the objective to be as narrow as possible, while still capturing the entirety of the thing. The **atomicity** of an evergreen note is the key requirement to **allow effective linking** between them.

