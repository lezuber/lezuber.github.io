---
categories:
- Updates
tags:
- ⌨️ My Blogpost
date: 2022-10-04
title: Hi there!
lastMod: 2022-10-07
---
I have no idea how you have found your way to this mostly empty, but beautiful, place!
Recently, I discovered this beautiful [Logseq]({{< ref "/pages/Logseq" >}})-Plugin [logseq-schrodinger](https://github.com/sawhney17/logseq-schrodinger) which converts my Knowledge Graph into a beautiful Hugo Website using this beautiful [template](https://github.com/CharlesChiuGit/Logseq-Hugo-Template).

I haven't decided yet, which pages I would like to publish and which not. Lets see how it goes! To start, checkout [Zettelkasten Method]({{< ref "/pages/Zettelkasten-Method" >}}).


