---
categories:
tags:
- App
- SaaS
- PKM
date: 2022-09-26
title: Logseq
lastMod: 2022-10-04
---
Logseq is one of the most powerful PKM Tools out there. My blog is generated out of my fork of logseq-graph using [logseq-schrodinger](https://github.com/sawhney17/logseq-schrodinger).
